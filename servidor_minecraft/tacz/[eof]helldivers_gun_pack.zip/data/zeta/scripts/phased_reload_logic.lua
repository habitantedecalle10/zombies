-- 定义逻辑机，定式

-- 此地为阶段性换弹实验性脚本，改动基础为tacz:xmag_reload_logic.lua

local M = {}

-- 当开始换弹的时候会调用一次
function M.start_reload(api)
    local continue = api:isOverheatLocked()
    local cache ={
        continue_reload = continue
    } --开始换弹时如果为热锁状态，则说明本次换弹为接续换弹
    api:cacheScriptData(cache)
    return true
end

-- 这是个 lua 函数，用来从枪 data 文件里获取装弹相关的动画时间点，由于 lua 内的时间是毫秒，所以要和 1000 做乘算
local function getReloadTimingFromParam(param)
    local reload_feed = param.reload_feed
    local reload_cooldown = param.reload_cooldown
    local empty_feed = param.empty_feed
    local empty_cooldown = param.empty_cooldown

    local empty_stage = param.empty_stage --空仓状态阶段分划点，在换弹时间越过该点后被打断时，进入热锁状态，使下次换弹使用缩短的接续换弹

    local continue_feed = param.continue_feed --接续换弹的两个数据
    local continue_cooldown = param.continue_cooldown

    if (reload_feed == nil or reload_cooldown == nil or empty_feed == nil or empty_cooldown == nil or empty_stage == nil or continue_feed == nil or continue_cooldown == nil) then
        return nil, nil, nil, nil, nil, nil, nil
    end
    reload_feed = reload_feed * 1000
    reload_cooldown = reload_cooldown * 1000
    empty_feed = empty_feed * 1000
    empty_cooldown = empty_cooldown * 1000
    empty_stage = empty_stage * 1000
    continue_feed = continue_feed * 1000
    continue_cooldown = continue_cooldown * 1000

    return reload_feed, reload_cooldown, empty_feed, empty_cooldown, empty_stage, continue_feed, continue_cooldown
end

-- 判断这个状态是否是空仓换弹过程中的其中一个阶段。包括空仓换弹的收尾阶段
local function isReloadingEmpty(stateType)
    return stateType == EMPTY_RELOAD_FEEDING or stateType == EMPTY_RELOAD_FINISHING
end

-- 判断这个状态是否是战术换弹过程中的其中一个阶段。包括战术换弹的收尾阶段
local function isReloadingTactical(stateType)
    return stateType == TACTICAL_RELOAD_FEEDING or stateType == TACTICAL_RELOAD_FINISHING
end

-- 判断这个状态是否是任意换弹过程中的其中一个阶段。包括任意换弹的收尾阶段
local function isReloading(stateType)
    return isReloadingEmpty(stateType) or isReloadingTactical(stateType)
end

-- 判断这个状态是否是任意换弹过程中的的收尾阶段
local function isReloadFinishing(stateType)
    return stateType == EMPTY_RELOAD_FINISHING or stateType == TACTICAL_RELOAD_FINISHING
end

local function finishReload(api, is_tactical)
    api:setOverheatLocked(false) --换弹正式结束时取消热锁
    local needAmmoCount = api:getNeededAmmoAmount();
    if (api:isReloadingNeedConsumeAmmo()) then
        -- 需要消耗弹药（生存或冒险）的话就消耗换弹所需的弹药并将消耗的数量装填进弹匣
        api:putAmmoInMagazine(api:consumeAmmoFromPlayer(needAmmoCount))
    else
        -- 不需要消耗弹药（创造）的话就直接把弹匣塞满
        api:putAmmoInMagazine(needAmmoCount)
    end
end

function M.tick_heat(api, heatTimestamp)
end

function M.tick_reload(api)
    local cache = api:getCachedScriptData() 
    -- 从枪 data 文件中获取所有需要传入逻辑机的参数，注意此时的 param 是个列表，还不能直接拿来用
    local param = api:getScriptParams();
    -- 调用刚才的 lua 函数，把 param 里包含的八个参数依次赋值给我们新定义的变量
    local reload_feed, reload_cooldown, empty_feed, empty_cooldown, empty_stage, continue_feed, continue_cooldown = getReloadTimingFromParam(param)
    -- 照例检查是否有参数缺失
    if (reload_feed == nil or reload_cooldown == nil or empty_feed == nil or empty_cooldown == nil or empty_stage == nil or continue_feed == nil or continue_cooldown == nil) then
        return NOT_RELOADING, -1
    end

    local countDown = -1
    local stateType = NOT_RELOADING
    local oldStateType = api:getReloadStateType()

    if cache.continue_reload then
        empty_cooldown = continue_cooldown
        empty_feed = continue_feed
    end --如果是接续换弹，则覆盖部分换弹属性

    -- 获取换弹时间，在玩家按下 R 的一瞬间作为零点，单位是毫秒。假设玩家在一秒前按下了 R ，那么此时这个时间就是 1000
    local progressTime = api:getReloadTime()

    if isReloadingEmpty(oldStateType) then
        local feed_time = empty_feed
        local finishing_time = empty_cooldown
        if progressTime < feed_time then
            stateType = EMPTY_RELOAD_FEEDING
            countDown = feed_time - progressTime
        elseif progressTime < finishing_time then
            stateType = EMPTY_RELOAD_FINISHING
            countDown = finishing_time - progressTime
        else
            stateType = NOT_RELOADING;
            countDown = -1
        end
    elseif isReloadingTactical(oldStateType) then
        local feed_time = reload_feed
        local finishing_time = reload_cooldown
        if progressTime < feed_time then
            stateType = TACTICAL_RELOAD_FEEDING
            countDown = feed_time - progressTime
        elseif progressTime < finishing_time then
            stateType = TACTICAL_RELOAD_FINISHING
            countDown = finishing_time - progressTime
        else
            stateType = NOT_RELOADING;
            countDown = -1
        end
    else
        stateType = NOT_RELOADING;
        countDown = -1
    end

    if oldStateType == EMPTY_RELOAD_FEEDING and oldStateType ~= stateType then
        finishReload(api,false);
    end

    if oldStateType == TACTICAL_RELOAD_FEEDING and oldStateType ~= stateType then
        finishReload(api, true);
    end

    if (progressTime > empty_stage)and(progressTime < empty_feed)and(not cache.continue_reload) then
        api:setOverheatLocked(true) --非接续状态下，越过分划点且未到达feed时打开热锁
    end

    return stateType, countDown
end

function M.handle_shoot_heat(api)
end


-- 向模组返回整个逻辑机，定式
return M