local M = {}

function M.shoot(api)
    api:shootOnce(api:isShootingNeedConsumeAmmo())
    api:removeAmmoFromMagazine(2)
end

return M